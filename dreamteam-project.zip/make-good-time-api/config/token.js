module.exports = {
  secret: "dkczDBSIsdcUCsdsdOY73Y8EzczP239Esc8UWDCUsdHsdcNSDKVpcsWDC8W"
}
