# Make Good Time
[copy about the app]
[splash screen screenshot]

## Planning

[description of planning process]
[trello screenshot]
[wireframe screenshot]

## Project Requirements

## Build

Using BCrypt with JSON Web Tokens for authentication
Node.js with Express and MongoDB/Mongoose
Google Maps Javascript API, Google Maps Directions Service API
Bower to manage client-side dependencies (Bootstrap, Underscore for templates)
AJAX
Mocha, Chai for testing; Istanbul for test coverage reporting
[app screenshot with map plotting]
[tests run and coverage screenshot from terminal]

## Unsolved Problems

[TBD]

## Credits

# dreamteam
Kaitlyn Tierney
Axel Berdugo
Andy Xiang-Hua Liu